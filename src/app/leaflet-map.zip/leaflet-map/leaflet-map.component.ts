import { Component, AfterViewInit } from '@angular/core';
import * as L from 'leaflet';


@Component({
  selector: 'app-leaflet-map',
  templateUrl: './leaflet-map.component.html',
  styleUrls: ['./leaflet-map.component.css']
})
export class LeafletMapComponent implements AfterViewInit {
 private defaultIcon_Darkshade: L.Icon = L.icon({
    iconUrl: 'assets/2053434.png',
    shadowUrl: 'assets/marker-shadow.png',
    iconSize: [21, 31],
    iconAnchor: [10, 41],
    popupAnchor: [1, 10],
    tooltipAnchor: [16, -28],
    shadowSize: [41, 41]
  });

  private map_Darkshade: any;

  private initMapDarkshade(): void {
    L.Marker.prototype.options.icon = this.defaultIcon_Darkshade;
    this.map_Darkshade = L.map('map-Darkshade', {
      center: [0, 0],
      zoom: 2
    });
    

    const tiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 12,
      minZoom: 2,
      attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    });
    tiles.addTo(this.map_Darkshade);

    const popupContent_Darkshade = `
    <table style="border-collapse: separate; border-spacing: 10px;">
    <tr>
      <th>
        <span style="color: purple">Site</span>
        &nbsp;
        <span style="color: black">VirtuDesk Kodathi</span>
        <hr style="border: 1px solid black;">
      </th>
    </tr>
  
    <tr>
      <td style="vertical-align: middle;">
        <img src="assets/yellow-circle.png" alt="Warning Image" style="height: 10px;">
      </td>
      <td style="vertical-align: middle;">
        <img src="assets/brown-color.png" alt="Warning Image" style="height: 10px;">
      </td>
    </tr>
    <tr>
      <td style="vertical-align: middle;">Warning</td>
      <td style="vertical-align: middle;">Critical</td>
    </tr>
    <tr>
      <td style="vertical-align: middle; color: yellow;">&nbsp;4</td>
      <td style="vertical-align: middle; color: brown;">15</td>
    </tr>
    <tr>
      <td style="vertical-align: middle;">
        Analytics &nbsp;
        <img src="assets/analytics.png" alt="analytics Image" style="height: 10px;">
      </td>
      <td style="vertical-align: middle;">
        Hourly Report &nbsp;
        <img src="assets/analytics.png" alt="analytics Image" style="height: 10px;">
      </td>
    </tr>
    <!-- Add more rows as needed -->
    </table>
  `;
//India ------------------------------------------------------------------

  // Add a marker with the custom popup
  const customPopupMarker1_Darkshade = L.marker([17.385044, 78.486671]).addTo(this.map_Darkshade);
  customPopupMarker1_Darkshade.bindPopup(popupContent_Darkshade);


    var CartoDB_DarkMatter = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
      subdomains: 'abcd',
      maxZoom: 20
    });
    CartoDB_DarkMatter.addTo(this.map_Darkshade);

    // Image icons for New York and Brazil
    const iconNewYork = L.icon({
      iconUrl: 'assets/red-color-icon.png', // Specify the path to the New York image
      iconSize: [32, 32] // Adjust the size as needed
    });

    const iconBrazil = L.icon({
      iconUrl: 'assets/grey-color-icon.png', // Specify the path to the Brazil image
      iconSize: [32, 32] // Adjust the size as needed
    });

    const iconMexico = L.icon({
      iconUrl: 'assets/grey-color-icon.png', // Specify the path to the Brazil image
      iconSize: [32, 32] // Adjust the size as needed
    });

    // Add markers for New York and Brazil with custom icons
    const markerNewYork = L.marker([40.7128, -74.0060], { icon: iconNewYork }).addTo(this.map_Darkshade);//south west coordinates
    const markerBrazil = L.marker([-14.2350, -51.9253], { icon: iconBrazil }).addTo(this.map_Darkshade);//south west coordinates
    const markerMexico = L.marker([24.967100389831334, -106.72650845888246], { icon: iconMexico }).addTo(this.map_Darkshade); //south west coordinates 

    // Add popups to the markers
    markerNewYork.bindPopup('loremdsod'); //---content of popup
    markerBrazil.bindPopup('Brazil'); //---content of popup
    markerMexico.bindPopup('Mexico'); //---content of popup
  }

  constructor() { }

  ngAfterViewInit(): void {
    this.initMapDarkshade();
  }
}